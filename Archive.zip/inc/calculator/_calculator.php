<link rel="stylesheet" href="css/calculator-style.css">
<script defer src="js/app-calculator.js"></script>