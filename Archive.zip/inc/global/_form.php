<!-- Inputs, Mask, Selects, Calendar -->
<link href="css/vendors/sumoselect.min.css" rel="stylesheet" type="text/css" />
<link href="css/form-style.css" rel="stylesheet" type="text/css" />
<script defer src="js/vendors/jquery.inputmask.min.js"></script>
<script defer src="js/vendors/jquery.sumoselect.min.js"></script>
<script defer src="js/app-form.js"></script>