<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="Put your description here.">
<meta name="format-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2">
<meta name="theme-color" content="var(--clr-white)" />

<link rel="shortcut icon" href="img/favicon.ico" />
<link href="css/main.css" rel="stylesheet" type="text/css" />
<?php include 'fonts/_fonts-top.php';?>