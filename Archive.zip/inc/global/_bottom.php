<!-- Global -->
<link href="css/vendors/bootstrap-grid.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script defer src="js/vendors/jquery.min.js"></script>
<script defer src="js/app-global.js"></script>