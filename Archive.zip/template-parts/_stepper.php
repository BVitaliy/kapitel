<div class="stepper stepper-zoom js_zoom d-none d-xl-flex">
    <button class="decr" type="button">-</button>
    <input value="100%" readonly="" tabindex="-1">
    <button class="incr" type="button">+</button>
</div>