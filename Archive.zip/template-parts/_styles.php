<div class="styles-wrap">
    <button class="filters-close active d-none d-lg-flex" data-toggle-more="Розгорнути" data-toggle-less="Згорнути">
        <i></i>
    </button>
    <div class="filters-bg active">
        <div class="filters-subtitle">
            Вибір готового стилю:
        </div>
        <div class="filters">
            <div class="filters-img active" data-style-id="1" data-image-target="kitchen-main-1" data-image="img/content/kitchen-image.jpg">
                <picture>
                    <source srcset="img/content/style-image4.webp" type="image/webp">
                    <source srcset="img/content/style-image4.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>            
            <div class="filters-img " data-style-id="2" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image-1.jpg">
                <picture>
                    <source srcset="img/content/style-image1.webp" type="image/webp">
                    <source srcset="img/content/style-image1.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
            <div class="filters-img" data-style-id="3" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image-2.jpg">
                <picture>
                    <source srcset="img/content/style-image2.webp" type="image/webp">
                    <source srcset="img/content/style-image2.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
            <div class="filters-img" data-style-id="4" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image-3.jpg">
                <picture>
                    <source srcset="img/content/style-image3.webp" type="image/webp">
                    <source srcset="img/content/style-image3.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
 
            <div class="filters-img" data-style-id="5" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image.jpg">
                <picture>
                    <source srcset="img/content/style-image5.webp" type="image/webp">
                    <source srcset="img/content/style-image5.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
            <div class="filters-img" data-style-id="6" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image.jpg">
                <picture>
                    <source srcset="img/content/style-image6.webp" type="image/webp">
                    <source srcset="img/content/style-image6.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
            <div class="filters-img" data-style-id="6" data-image-target="kitchen-main-1" data-image="img/_temp/kitchen-image.jpg">
                <picture>
                    <source srcset="img/content/style-image7.webp" type="image/webp">
                    <source srcset="img/content/style-image7.jpg" type="image/jpg">
                    <img width="380" height="240" src="#" alt="" loading="lazy">
                </picture>
            </div>
        </div>
    </div>
</div>